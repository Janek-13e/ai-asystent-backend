🧠 AI Asystent Głosowy – Instrukcja uruchomienia

📁 Struktura:
- frontend/ – interfejs użytkownika z mikrofonem, głosem i przełącznikiem "Mów/Pisz"
- backend/ – Node.js + Express, łączący się z OpenAI
- README.txt – ta instrukcja

🚀 Jak uruchomić lokalnie:

1. W pliku backend/.env wklej swój klucz OpenAI:
   OPENAI_API_KEY=tu_wklej_swoj_klucz

2. Odpal backend:
   cd backend
   npm install
   node index.js

3. W pliku frontend/script.js podmień adres backendu jeśli trzeba.

4. Otwórz frontend/index.html w przeglądarce (najlepiej Chrome).

💡 Możesz też wrzucić frontend na Vercel, backend na Render.

Powodzenia!
